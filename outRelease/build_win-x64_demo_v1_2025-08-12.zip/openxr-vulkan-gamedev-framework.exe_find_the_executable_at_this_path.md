
Windows:
./build/x64-Release/src/RelWithDebInfo/openxr-vulkan-framework.exe


